package pojo;

import java.util.List;

public class pojoClass {
	private String name;

    private String job;
	
//	    public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}
//
//	public String getJob() {
//		return job;
//	}
//
//	public void setJob(String job) {
//		this.job = job;
//	}

	public pojoClass(String name, String job) {
    	
    	this.name=name;
    	this.job=job;
	}
}
